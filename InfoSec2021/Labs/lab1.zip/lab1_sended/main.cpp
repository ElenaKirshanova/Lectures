#include <iostream>
#include <interface_ssl.h>

int main() {
    Interface_ssl *obj = new Interface_ssl();
    char *key = obj->KeyGen();
    char string[] = "Hello, World!";
    char enc_str[100];
    std::cout << string << std::endl;
    int a = obj->Enc(key, string, enc_str);
    std::cout << enc_str << std::endl;
    char dec_str[100];
    int len_dec_text = obj->Dec(key, enc_str, dec_str, a);
    dec_str[len_dec_text] = 0;
    std::cout << dec_str << std::endl;
    free(obj);
    return 0;
}
