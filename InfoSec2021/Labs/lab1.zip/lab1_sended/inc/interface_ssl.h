//
// Created by arseniy on 05.03.2020.
//

#ifndef LAB1_INTERFACE_SSL_H
#define LAB1_INTERFACE_SSL_H

class Interface_ssl {
private:
    unsigned char *iv;

public:
    // Constructor interface class
    Interface_ssl();
    // Destructor interface class
    ~Interface_ssl();
    // Generate key for function Enc, Dec
    char *KeyGen();
    // Encrypting string
        // key - key from function KeyGen
        // string - not unencrypted text
        // encrypted_text - encrypted text
    int Enc(const char *key, const char *string, char *encrypted_text);
    // Decrypting string
        // key - key from function KeyGen
        // string - not unencrypted text
        // encrypted_text - encrypted text
        // len_enc - len encrypted string from function Enc
    int Dec(const char *key, const char *encrypted_text, char *string, int len_enc);

};

#endif //LAB1_INTERFACE_SSL_H
