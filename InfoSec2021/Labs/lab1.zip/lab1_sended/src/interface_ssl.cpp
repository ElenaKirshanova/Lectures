//
// Created by arseniy on 05.03.2020.
//

#include <cstring>
#include "interface_ssl.h"
# include  "openssl/bio.h"
# include  "openssl/ssl.h"
# include  "openssl/err.h"

Interface_ssl::Interface_ssl() {
    iv = (unsigned char *) EVP_chacha20();
}

Interface_ssl::~Interface_ssl() {
    free(iv);
}

char *Interface_ssl::KeyGen() {
    return (char *) EVP_chacha20();
}

static void handleErrors() {
    ERR_print_errors_fp(stderr);
    abort();
}

int Interface_ssl::Enc(const char *key, const char *string, char *encrypted_text) {
    EVP_CIPHER_CTX *ctx;
    if (!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();
    if (1 != EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, (unsigned char *) key, this->iv))
        handleErrors();
    int len;
    if (1 != EVP_EncryptUpdate(ctx, (unsigned char *) encrypted_text, &len, (unsigned char *) string,
                               strlen((char *) string)))
        handleErrors();
    int encrypted_text_len = len;
    if (1 != EVP_EncryptFinal_ex(ctx, (unsigned char *) encrypted_text + len, &len))
        handleErrors();
    encrypted_text_len += len;
    EVP_CIPHER_CTX_free(ctx);
    return encrypted_text_len;
}

int Interface_ssl::Dec(const char *key, const char *encrypted_text, char *string, int len_enc) {
    EVP_CIPHER_CTX *ctx;
    if (!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();
    if (1 != EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, (unsigned char *) key, this->iv))
        handleErrors();
    int len;

    if (1 != EVP_DecryptUpdate(ctx, (unsigned char *) string, &len, (unsigned char *) encrypted_text, len_enc))
        handleErrors();
    int string_len = len;
    if (1 != EVP_DecryptFinal_ex(ctx, (unsigned char *) encrypted_text + len, &len))
        handleErrors();
    string_len += len;
    EVP_CIPHER_CTX_free(ctx);
    return string_len;
}
